export default {
  logger: self.console,
  WebSocket: self.WebSocket
}
